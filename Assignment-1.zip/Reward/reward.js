//here we can store the user reward data
const rewards = [];

module.exports = rewards;